﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBBRARY_MANAGER.Views.BookViews
{
    /// <summary>
    /// Logique d'interaction pour BookListItemView.xaml
    /// </summary>
    public partial class BookListItem: UserControl
    {
        public string DisplayCoverUrl { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string DisplayCategory { get; set; }
        public string ISBN { get; set; }
        public string Publisher { get; set; }
        public DateTime PublicationDate { get; set; }
        public string Language { get; set; }
        public int Quantity { get; set; }
        public SolidColorBrush AvailabilityColor { get; set; }
        public DateTime AddedOn { get; set; }

        public bool IsNew { get; set; }
        public bool IsPopular { get; set; }
        public bool IsSelected { get; set; }

        public RoutedEvent ViewDetailsCommand { get; }
        public RoutedEvent BorrowCommand { get; }
        public BookListItem()
        {
            InitializeComponent();
        }

    }
}
