﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views;
using LIBBRARY_MANAGER.ViewModel.BookViewModels;

namespace LIBBRARY_MANAGER.Views.BookViews
{

        public partial class BookBorrowPanel : UserControl
        {
            public BookBorrowPanel()
            {
                InitializeComponent();
                ReturnDatePicker.SelectedDate = DateTime.Now.AddDays(14);
            }

            private void CloseButton_Click(object sender, RoutedEventArgs e)
            {
                
            }

            private void SubscriberSearchBox_TextChanged(object sender, TextChangedEventArgs e)
            {
                // TODO: Implémenter la recherche d'abonnés
            }

            private void Set7Days_Click(object sender, RoutedEventArgs e)
            {
                ReturnDatePicker.SelectedDate = DateTime.Now.AddDays(7);
            }

            private void Set14Days_Click(object sender, RoutedEventArgs e)
            {
                ReturnDatePicker.SelectedDate = DateTime.Now.AddDays(14);
            }

            private void Set21Days_Click(object sender, RoutedEventArgs e)
            {
                ReturnDatePicker.SelectedDate = DateTime.Now.AddDays(21);
            }

            private void ConfirmBorrowButton_Click(object sender, RoutedEventArgs e)
            {
                if (DataContext is BookViewModel bookVM)
                {
                    // TODO: Implémenter la logique d'emprunt
                    MessageBox.Show($"Emprunt du livre '{bookVM.Title}' confirmé!\n\nDate de retour: {ReturnDatePicker.SelectedDate:dd/MM/yyyy}",
                                  "Succès",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);

                    CloseButton_Click(sender, e);
                }
            }

            private T? FindParent<T>(DependencyObject child) where T : DependencyObject
            {
                var parent = System.Windows.Media.VisualTreeHelper.GetParent(child);

                if (parent == null)
                    return null;

                if (parent is T typedParent)
                    return typedParent;

                return FindParent<T>(parent);
            }
        }
}


