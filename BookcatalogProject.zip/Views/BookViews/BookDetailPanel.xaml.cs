﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views.MainView;
using LIBBRARY_MANAGER.ViewModel.BookViewModels;

namespace LIBBRARY_MANAGER.Views.BookViews
{

        public partial class BookDetailPanel : UserControl
        {
            public BookDetailPanel()
            {
                InitializeComponent();
            }

            private void CloseButton_Click(object sender, RoutedEventArgs e)
            {
                // Le ViewModel parent gérera la fermeture
                if (DataContext is BookViewModel bookVM)
                {
                    // Notifier le parent via un event ou command
          
                }
            }

            private void BorrowButton_Click(object sender, RoutedEventArgs e)
            {
                if (DataContext is BookViewModel bookVM)
                {
                 
                }
            }

            private void EditButton_Click(object sender, RoutedEventArgs e)
            {
                MessageBox.Show("Fonction d'édition à implémenter",
                              "Info",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
            }

            private T? FindParent<T>(DependencyObject child) where T : DependencyObject
            {
                var parent = System.Windows.Media.VisualTreeHelper.GetParent(child);

                if (parent == null)
                    return null;

                if (parent is T typedParent)
                    return typedParent;

                return FindParent<T>(parent);
            }
        }
    
}
