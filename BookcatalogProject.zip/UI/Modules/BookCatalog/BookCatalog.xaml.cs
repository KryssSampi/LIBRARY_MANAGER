﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using GalaSoft.MvvmLight.CommandWpf;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Core.Services.LIBBRARY_MANAGER.Services.BookCatalog;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.ViewModels;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views.HomeView;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views.MainView;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog
{
    /// <summary>
    /// Orchestrateur principal du module BookCatalog
    /// Gère la navigation fluide entre HomeView et MainView
    /// </summary>
    public partial class BookCatalog : UserControl
    {
        #region Propriétés

        private BookCatalogMainViewModel _mainViewModel;
        private HomeView _homeView;
        private Mainview _mainView;
        private CategoryCountService _categoryCountService;

        private UserControl? _currentView;

        #endregion

        #region Constructeur

        public BookCatalog()
        {
            InitializeComponent();

            // Initialisation des services
            _categoryCountService = new CategoryCountService();

            // Initialisation du ViewModel principal
            _mainViewModel = new BookCatalogMainViewModel();

            // Création des vues
            InitializeViews();

            // Configuration de la navigation
            SetupNavigation();

            // Affichage initial de la HomeView
            NavigateToHome(animate: false);

            Loaded += BookCatalog_Loaded;
        }

        #endregion

        #region Initialisation

        private void InitializeViews()
        {
            // HomeView : sélection de catégories
            _homeView = new HomeView();

            // MainView : affichage de la liste/grille
            _mainView = new Mainview(_mainViewModel);
        }

        private void SetupNavigation()
        {
            // HomeView → MainView (sélection de catégorie)
            _homeView.CategoriesGrid.OnCategorySelected += OnCategorySelected;

            // MainView → HomeView (bouton retour)
            _mainViewModel.BackCommand = new RelayCommand(() => NavigateToHome(true));

            // Synchronisation des compteurs de catégories
            UpdateCategoryCounts();
        }

        private void BookCatalog_Loaded(object sender, RoutedEventArgs e)
        {
            // Mise à jour des compteurs au chargement
            UpdateCategoryCounts();
        }

        #endregion

        #region Navigation



        /// <summary>
        /// Navigation vers HomeView
        /// </summary>
        private void NavigateToHome(bool animate = true)
        {
            NavigateTo(_homeView, animate);
            UpdateCategoryCounts();
        }

        /// <summary>
        /// Gestion de la sélection d'une catégorie (HomeView → MainView)
        /// </summary>
        private void OnCategorySelected(Model.Book.CategoryAllowed category)
        {
            try
            {
                // Charger les livres de la catégorie dans le ViewModel
                _mainViewModel.LoadBooksForCategory(category);

                // Naviguer vers MainView
                NavigateTo(_mainView, animate: true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Erreur lors du chargement de la catégorie:\n{ex.Message}",
                    "Erreur",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }

        /// <summary>
        /// Navigation générique avec animation fluide
        /// </summary>
        private void NavigateTo(UserControl targetView, bool animate = true)
        {
            if (targetView == null || targetView == _currentView)
                return;

            if (animate)
            {
                // Animation de fade-out de la vue actuelle
                if (_currentView != null)
                {
                    var fadeOut = new DoubleAnimation
                    {
                        From = 1.0,
                        To = 0.0,
                        Duration = TimeSpan.FromMilliseconds(200),
                        EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn }
                    };

                    fadeOut.Completed += (s, e) =>
                    {
                        // Changement de contenu
                        MainContent.Content = targetView;
                        _currentView = targetView;

                        // Animation de fade-in de la nouvelle vue
                        var fadeIn = new DoubleAnimation
                        {
                            From = 0.0,
                            To = 1.0,
                            Duration = TimeSpan.FromMilliseconds(250),
                            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
                        };

                        MainContent.BeginAnimation(OpacityProperty, fadeIn);
                    };

                    MainContent.BeginAnimation(OpacityProperty, fadeOut);
                }
                else
                {
                    // Première navigation (pas de fade-out)
                    MainContent.Content = targetView;
                    _currentView = targetView;

                    var fadeIn = new DoubleAnimation
                    {
                        From = 0.0,
                        To = 1.0,
                        Duration = TimeSpan.FromMilliseconds(250),
                        EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
                    };

                    MainContent.BeginAnimation(OpacityProperty, fadeIn);
                }
            }
            else
            {
                // Navigation sans animation
                MainContent.Content = targetView;
                _currentView = targetView;
            }
        }

        #endregion

        #region Mise à jour des compteurs

        /// <summary>
        /// Met à jour les compteurs de livres par catégorie (HomeView)
        /// </summary>
        private void UpdateCategoryCounts()
        {
            try
            {
                var counts = _mainViewModel.GetCategoryCounts();
                _homeView.CategoriesGrid.UpdateCategoryCounts(counts);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Erreur mise à jour compteurs: {ex.Message}");
            }
        }

        #endregion

        #region Méthodes publiques (API externe)

        /// <summary>
        /// Force la navigation vers HomeView
        /// </summary>
        public void ShowHome()
        {
            NavigateToHome();
        }

        /// <summary>
        /// Navigation directe vers une catégorie
        /// </summary>
        public void ShowCategory(Model.Book.CategoryAllowed category)
        {
            OnCategorySelected(category);
        }

        /// <summary>
        /// Rafraîchit les données
        /// </summary>
        public void RefreshData()
        {
            _mainViewModel.ReloadCommand.Execute(null);
            UpdateCategoryCounts();
        }

        /// <summary>
        /// Obtient le ViewModel principal (pour binding externe)
        /// </summary>
        public BookCatalogMainViewModel GetViewModel() => _mainViewModel;

        #endregion
    }
}