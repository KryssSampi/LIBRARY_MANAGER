﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LIBBRARY_MANAGER.UI.Common.Items;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items
{
    /// <summary>
    /// Logique d'interaction pour ActiveFiltersPanel.xaml
    /// </summary>
    public partial class ActiveFiltersPanel : UserControl
    {
        public ObservableCollection<FilterLabelViewModel> Filters
        {
            get => (ObservableCollection<FilterLabelViewModel>)GetValue(FiltersProperty);
            set => SetValue(FiltersProperty, value);
        }
        public static readonly DependencyProperty FiltersProperty =
            DependencyProperty.Register(nameof(Filters), typeof(ObservableCollection<FilterLabelViewModel>), typeof(ActiveFiltersPanel), new PropertyMetadata(new ObservableCollection<FilterLabelViewModel>(), OnFiltersChanged));

        public ICommand CloseFilterCommand
        {
            get => (ICommand)GetValue(CloseFilterCommandProperty);
            set => SetValue(CloseFilterCommandProperty, value);
        }
        public static readonly DependencyProperty CloseFilterCommandProperty =
            DependencyProperty.Register(nameof(CloseFilterCommand), typeof(ICommand), typeof(ActiveFiltersPanel), new PropertyMetadata(null));

        public Brush FilterForeground
        {
            get => (Brush)GetValue(FilterForegroundProperty);
            set => SetValue(FilterForegroundProperty, value);
        }
        public static readonly DependencyProperty FilterForegroundProperty =
            DependencyProperty.Register(nameof(FilterForeground), typeof(Brush), typeof(ActiveFiltersPanel), new PropertyMetadata(Brushes.Black));

        public Brush FilterBackground
        {
            get => (Brush)GetValue(FilterBackgroundProperty);
            set => SetValue(FilterBackgroundProperty, value);
        }
        public static readonly DependencyProperty FilterBackgroundProperty =
            DependencyProperty.Register(nameof(FilterBackground), typeof(Brush), typeof(ActiveFiltersPanel), new PropertyMetadata(Brushes.White));

        public ActiveFiltersPanel()
        {
            InitializeComponent();
            Loaded += (s, e) => RefreshFilterLabels();
        }

            private static void OnFiltersChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is ActiveFiltersPanel panel)
            {
                panel.RefreshFilterLabels();
            }
        }

        public void RefreshFilterLabels()
        {
            FiltersGrid.Children.Clear();
            if (Filters == null) return;

            foreach (var filter in Filters)
            {
                var label = new ActiveFiltersLabel
                {
                    TypeText = filter.Type,
                    ValueText = filter.Value,
                    FilterId = filter.Id,                   
                    CloseCommand = CloseFilterCommand,
                    Foreground = FilterForeground,
                    LabelBackground = FilterBackground
                };
                label.CloseButton.AddHandler(IconButton.ClickEvent, new RoutedEventHandler((sender, e) => {
                    Filters.Remove(filter);
                    RefreshFilterLabels();
                }));
                FiltersGrid.Children.Add(label);
            }
        }
    }

    public class FilterLabelViewModel
    {
        public string Type { get; set; }
        public string Value { get; set; }
        public object Id { get; set; }
    } 
}
