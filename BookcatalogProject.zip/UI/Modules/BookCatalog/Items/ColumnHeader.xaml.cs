﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items
{

        public partial class ColumnHeader : UserControl
        {
            public static readonly DependencyProperty HeaderNameProperty =
                DependencyProperty.Register(nameof(HeaderName), typeof(string), typeof(ColumnHeader));
            public string HeaderName { get => (string)GetValue(HeaderNameProperty); set => SetValue(HeaderNameProperty, value); }

            public static readonly DependencyProperty AllowFilterProperty =
                DependencyProperty.Register(nameof(AllowFilter), typeof(bool), typeof(ColumnHeader));
            public bool AllowFilter { get => (bool)GetValue(AllowFilterProperty); set => SetValue(AllowFilterProperty, value); }

            public static readonly DependencyProperty IsSortedProperty =
                DependencyProperty.Register(nameof(IsSorted), typeof(bool), typeof(ColumnHeader), new PropertyMetadata(false));
            public bool IsSorted { get => (bool)GetValue(IsSortedProperty); set { SetValue(IsSortedProperty, value); OnPropertyChanged(nameof(SortGlyph)); } }

            public static readonly DependencyProperty SortDirectionProperty =
                DependencyProperty.Register(nameof(SortDirection), typeof(bool), typeof(ColumnHeader));
            public bool SortDirection { get => (bool)GetValue(SortDirectionProperty); set { SetValue(SortDirectionProperty, value); OnPropertyChanged(nameof(SortGlyph)); } }
            // True=ASC, False=DESC

            public static readonly DependencyProperty ClickCommandProperty =
                DependencyProperty.Register(nameof(ClickCommand), typeof(ICommand), typeof(ColumnHeader));
            public ICommand ClickCommand { get => (ICommand)GetValue(ClickCommandProperty); set => SetValue(ClickCommandProperty, value); }

            public static readonly DependencyProperty FilterOptionsProperty =
                DependencyProperty.Register(nameof(FilterOptions), typeof(System.Collections.ObjectModel.ObservableCollection<FilterOption>), typeof(ColumnHeader));
            public System.Collections.ObjectModel.ObservableCollection<FilterOption> FilterOptions { get => (ObservableCollection<FilterOption>)GetValue(FilterOptionsProperty); set => SetValue(FilterOptionsProperty, value); }

            public static readonly DependencyProperty BackgroundProperty =
                DependencyProperty.Register(nameof(Background), typeof(Brush), typeof(ColumnHeader), new PropertyMetadata(Brushes.Transparent));
            public new Brush Background { get => (Brush)GetValue(BackgroundProperty); set => SetValue(BackgroundProperty, value); }

            public static readonly DependencyProperty ForegroundProperty =
                DependencyProperty.Register(nameof(Foreground), typeof(Brush), typeof(ColumnHeader), new PropertyMetadata(Brushes.Black));
            public new Brush Foreground { get => (Brush)GetValue(ForegroundProperty); set => SetValue(ForegroundProperty, value); }

            public string SortGlyph =>
                !IsSorted ? "" : (SortDirection ? "▲" : "▼");

            public  ColumnHeader()
            {

                InitializeComponent();            
                DataContext = this;
            }

            public event PropertyChangedEventHandler? PropertyChanged;
            private void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public class FilterOption
        {
        public string Label { get; set; } = "Undefined";
            public bool IsChecked { get; set; }
        }
   }
