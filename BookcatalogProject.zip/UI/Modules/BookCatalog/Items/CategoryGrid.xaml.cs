﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LIBBRARY_MANAGER.Model;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Config;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Config;
using static LIBBRARY_MANAGER.Model.Book;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items
{
    public partial class CategoryGrid : UserControl
    {
        #region Fields

        private Dictionary<CategoryAllowed, CategoryTile> _tiles;
        private Dictionary<CategoryAllowed, int> _categoryCounts;

        #endregion

        #region Events

        /// <summary>
        /// Event déclenché lorsqu'une catégorie est cliquée
        /// </summary>
        public event Action<CategoryAllowed> OnCategorySelected;

        #endregion

        #region Dependency Properties

        // Nombre de colonnes
        public static readonly DependencyProperty ColumnsProperty =
            DependencyProperty.Register(
                nameof(Columns),
                typeof(int),
                typeof(CategoryGrid),
                new PropertyMetadata(4, OnColumnsChanged));

        public int Columns
        {
            get => (int)GetValue(ColumnsProperty);
            set => SetValue(ColumnsProperty, value);
        }

        // Nombre de lignes (optionnel, auto si null)
        public static readonly DependencyProperty RowsProperty =
            DependencyProperty.Register(
                nameof(Rows),
                typeof(int?),
                typeof(CategoryGrid),
                new PropertyMetadata(null, OnRowsChanged));

        public int? Rows
        {
            get => (int?)GetValue(RowsProperty);
            set => SetValue(RowsProperty, value);
        }

        // Afficher seulement les catégories avec livres
        public static readonly DependencyProperty ShowOnlyWithBooksProperty =
            DependencyProperty.Register(
                nameof(ShowOnlyWithBooks),
                typeof(bool),
                typeof(CategoryGrid),
                new PropertyMetadata(false, OnShowOnlyWithBooksChanged));

        public bool ShowOnlyWithBooks
        {
            get => (bool)GetValue(ShowOnlyWithBooksProperty);
            set => SetValue(ShowOnlyWithBooksProperty, value);
        }

        #endregion

        #region Constructor

        public CategoryGrid()
        {
            InitializeComponent();
            _tiles = new Dictionary<CategoryAllowed, CategoryTile>();
            _categoryCounts = new Dictionary<CategoryAllowed, int>();

            Loaded += CategoryGrid_Loaded;
        }

        #endregion

        #region Initialization

        private void CategoryGrid_Loaded(object sender, RoutedEventArgs e)
        {
            LoadCategories();
        }

        /// <summary>
        /// Charge toutes les catégories depuis la configuration
        /// </summary>
        public void LoadCategories()
        {
            CategoriesContainer.Children.Clear();
            _tiles.Clear();

            var configs = CategoryConfiguration.GetAllConfigs().ToList();

            // Filtrer si nécessaire
            if (ShowOnlyWithBooks)
            {
                configs = configs.Where(c => GetCategoryCount(c.Category) > 0).ToList();
            }

            foreach (var config in configs)
            {
                CreateTile(config);
               
            }

            UpdateGridLayout();
        }

        /// <summary>
        /// Charge seulement certaines catégories spécifiées
        /// </summary>
        public void LoadSpecificCategories(IEnumerable<CategoryAllowed> categories)
        {
            CategoriesContainer.Children.Clear();
            _tiles.Clear();

            foreach (var category in categories)
            {
                var config = CategoryConfiguration.GetConfig(category);
                if (config != null)
                {
                    CreateTile(config);

                }
            }

            UpdateGridLayout();
        }

        #endregion

        #region Tile Creation

        private void CreateTile(CategoryConfig config)
        {
            var tile = new CategoryTile();
            tile.ConfigureFromCategoryConfig(config);

            // Mettre à jour le compteur
            int count = GetCategoryCount(config.Category);
            tile.UpdateBookCount(count);

            // Abonnement à l'event
            tile.OnCategoryClicked += HandleCategoryClick;

            // Ajouter au dictionnaire et au container
            _tiles[config.Category] = tile;
            CategoriesContainer.Children.Add(tile);
        }

        #endregion

        #region Event Handling

        private void HandleCategoryClick(CategoryAllowed category)
        {
            OnCategorySelected?.Invoke(category);
            SwitchView();
        }
        public delegate void SwitchViewDelegate();

        public  SwitchViewDelegate SwitchView;

     

        #endregion

        #region Public Methods - Data Management

        /// <summary>
        /// Met à jour les compteurs de livres depuis un dictionnaire
        /// </summary>
        public void UpdateCategoryCounts(Dictionary<CategoryAllowed, int> counts)
        {
            _categoryCounts = counts ?? new Dictionary<CategoryAllowed, int>();

            foreach (var kvp in _tiles)
            {
                int count = GetCategoryCount(kvp.Key);
                kvp.Value.UpdateBookCount(count);
            }

            // Si on affiche seulement les catégories avec livres, recharger
            if (ShowOnlyWithBooks)
            {
                LoadCategories();
            }
        }

        /// <summary>
        /// Met à jour le compteur d'une catégorie spécifique
        /// </summary>
        public void UpdateCategoryCount(CategoryAllowed category, int count)
        {
            _categoryCounts[category] = count;

            if (_tiles.TryGetValue(category, out var tile))
            {
                tile.UpdateBookCount(count);
            }

            // Si on affiche seulement les catégories avec livres, recharger
            if (ShowOnlyWithBooks)
            {
                LoadCategories();
            }
        }

        /// <summary>
        /// Charge les compteurs depuis le DbContext
        /// </summary>
        public void LoadCountsFromDatabase()
        {
            // TODO: À implémenter avec le DbContext
            // using (var context = new LibraryDbContext())
            // {
            //     var counts = context.Books
            //         .Where(b => !b.IsRemoved && b.Category != null)
            //         .GroupBy(b => b.Category)
            //         .ToDictionary(
            //             g => Enum.Parse<CategoryAllowed>(g.Key),
            //             g => g.Count()
            //         );
            //     
            //     UpdateCategoryCounts(counts);
            // }

            // Démo: données fictives
            var demoCounts = new Dictionary<CategoryAllowed, int>();
            foreach (CategoryAllowed category in Enum.GetValues(typeof(CategoryAllowed)))
            {
                demoCounts[category] = 0; // Remplacer par vraies données
            }
            UpdateCategoryCounts(demoCounts);
        }

        #endregion

        #region Private Helpers

        private int GetCategoryCount(CategoryAllowed category)
        {
            return _categoryCounts.TryGetValue(category, out int count) ? count : 0;
        }

        private void UpdateGridLayout()
        {
            CategoriesContainer.Columns = Columns;

            if (Rows.HasValue)
            {
                CategoriesContainer.Rows = Rows.Value;
            }
            else
            {
                // Calcul automatique du nombre de lignes
                int totalTiles = CategoriesContainer.Children.Count;
                CategoriesContainer.Rows = (int)Math.Ceiling((double)totalTiles / Columns);
            }
        }

        #endregion

        #region Dependency Property Changed Handlers

        private static void OnColumnsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is CategoryGrid grid)
            {
                grid.UpdateGridLayout();
            }
        }

        private static void OnRowsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is CategoryGrid grid)
            {
                grid.UpdateGridLayout();
            }
        }

        private static void OnShowOnlyWithBooksChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is CategoryGrid grid && grid.IsLoaded)
            {
                grid.LoadCategories();
            }
        }

        #endregion

        #region Public Utility Methods

        /// <summary>
        /// Obtient toutes les catégories actuellement affichées
        /// </summary>
        public IEnumerable<CategoryAllowed> GetDisplayedCategories()
        {
            return _tiles.Keys;
        }

        /// <summary>
        /// Vérifie si une catégorie est affichée
        /// </summary>
        public bool IsCategoryDisplayed(CategoryAllowed category)
        {
            return _tiles.ContainsKey(category);
        }

        /// <summary>
        /// Obtient le nombre total de livres affichés
        /// </summary>
        public int GetTotalBookCount()
        {
            return _categoryCounts.Values.Sum();
        }

        /// <summary>
        /// Rafraîchit complètement le grid
        /// </summary>
        public void Refresh()
        {
            LoadCountsFromDatabase();
        }

        #endregion
    }
}