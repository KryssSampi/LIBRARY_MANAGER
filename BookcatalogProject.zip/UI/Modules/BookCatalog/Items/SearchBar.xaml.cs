﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items
{
    /// <summary>
    /// Logique d'interaction pour SearchBar.xaml
    /// </summary>
    public partial class SearchBar : UserControl
    {
        public string Placeholder { get; set; } = "Rechercher un livre...";
        public Brush CardBackground { get; set; } = Brushes.White;
        public Color ShadowColor { get; set; } = Colors.Blue;
        public Brush ButtonColor { get; set; } = new SolidColorBrush(Colors.Blue);
        public double IconSize { get; set; } = 24;

        public event Action<string> OnSearchRequested;

        public SearchBar()
        {
            InitializeComponent();
        }

        public string GetSearchText() => SearchBox.Text?.Trim() ?? string.Empty;

        public void SetSearchText(string text) => SearchBox.Text = text;

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                SearchButton_Click(null, null);
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            OnSearchRequested?.Invoke(GetSearchText());
        }
    }

}
