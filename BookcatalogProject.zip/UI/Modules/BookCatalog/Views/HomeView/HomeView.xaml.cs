﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using LIBBRARY_MANAGER.Model;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Config;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Helpers;
using MahApps.Metro.IconPacks;
using static LIBBRARY_MANAGER.Model.Book;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views.HomeView
{
    public partial class HomeView : UserControl
    {

        public HomeView()
        {
            InitializeComponent();
            string relativePath = "UI/Common/Assets/BookCatalog_Images/HomeView_Background.png";
            Image_Background.ImageSource = GetPathHelpers.GetPathImagesource(relativePath);
            InitializeCategoryGrid();
        }

        #region Initialization

        private void InitializeCategoryGrid()
        {
            // Abonnement à l'event de sélection de catégorie
            CategoriesGrid.OnCategorySelected += HandleCategorySelected;

            // Charger les données depuis la base (ou démo)
            LoadCategoryData();
        }

        #endregion

        #region Data Loading

        /// <summary>
        /// Charge les données des catégories depuis le contexte
        /// </summary>
        private void LoadCategoryData()
        {
            try
            {
                // TODO: Connecter au DbContext pour obtenir les vraies données
                // using (var context = new LibraryDbContext())
                // {
                //     var categoryCounts = context.Books
                //         .Where(b => !b.IsRemoved && !string.IsNullOrEmpty(b.Category))
                //         .GroupBy(b => b.Category)
                //         .ToDictionary(
                //             g => Enum.Parse<CategoryAllowed>(g.Key),
                //             g => g.Count()
                //         );
                //     
                //     CategoriesGrid.UpdateCategoryCounts(categoryCounts);
                // }

                // Données de démonstration (à remplacer par vraies données)
                var demoCounts = new Dictionary<CategoryAllowed, int>
                {
                    { CategoryAllowed.Roman, 15 },
                    { CategoryAllowed.Science, 8 },
                    { CategoryAllowed.Histoire, 12 },
                    { CategoryAllowed.Technologie, 6 },
                    { CategoryAllowed.Art, 4 },
                    { CategoryAllowed.Philosophie, 7 },
                    { CategoryAllowed.Jeunesse, 20 },
                    { CategoryAllowed.Fantasy, 18 }
                };

                CategoriesGrid.UpdateCategoryCounts(demoCounts);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des catégories: {ex.Message}",
                              "Erreur",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }

        #endregion

        #region Virtual Methods - Search

        /// <summary>
        /// Méthode virtuelle appelée lors d'une recherche.
        /// À surcharger dans une classe dérivée ou à connecter à un ViewModel.
        /// </summary>
        /// <param name="searchQuery">Terme de recherche saisi</param>
        protected virtual void OnSearch(string searchQuery)
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                MessageBox.Show("Veuillez saisir un terme de recherche.",
                              "Recherche",
                              MessageBoxButton.OK,
                              MessageBoxImage.Information);
                return;
            }

            // TODO: Implémenter la logique de recherche avec DbContext
            // Exemple:
            // using (var context = new LibraryDbContext())
            // {
            //     var results = context.Books
            //         .Where(b => !b.IsRemoved &&
            //                    (b.Title.Contains(searchQuery) ||
            //                     b.Author.Contains(searchQuery) ||
            //                     b.ISBN.Contains(searchQuery) ||
            //                     (b.Category != null && b.Category.Contains(searchQuery))))
            //         .OrderBy(b => b.Title)
            //         .Take(50)
            //         .ToList();
            //
            //     if (results.Count == 0)
            //     {
            //         MessageBox.Show($"Aucun résultat trouvé pour '{searchQuery}'",
            //                       "Recherche",
            //                       MessageBoxButton.OK,
            //                       MessageBoxImage.Information);
            //         return;
            //     }
            //
            //     ShowSearchResultsView(results, searchQuery);
            // }

            MessageBox.Show($"Recherche pour: '{searchQuery}'\n\nRésultats:\n(Fonctionnalité à implémenter avec DbContext)",
                          "Recherche",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        #endregion

        #region Virtual Methods - Category Selection

        /// <summary>
        /// Méthode virtuelle appelée lors de la sélection d'une catégorie.
        /// À surcharger pour implémenter la navigation ou le filtrage.
        /// </summary>
        /// <param name="category">Catégorie sélectionnée</param>
        protected virtual void OnCategorySelected(CategoryAllowed category)
        {
            // TODO: Implémenter la navigation vers la liste filtrée
            // Exemple:
            // using (var context = new LibraryDbContext())
            // {
            //     var booksInCategory = context.Books
            //         .Where(b => !b.IsRemoved && b.Category == category.ToString())
            //         .OrderBy(b => b.Title)
            //         .ToList();
            //
            //     if (booksInCategory.Count == 0)
            //     {
            //         MessageBox.Show($"Aucun livre disponible dans la catégorie '{category}'",
            //                       "Catégorie",
            //                       MessageBoxButton.OK,
            //                       MessageBoxImage.Information);
            //         return;
            //     }
            //
            //     NavigateToCategoryView(booksInCategory, category);
            // }

            var config = CategoryConfiguration.GetConfig(category);
            string displayName = config?.DisplayName ?? category.ToString();

            MessageBox.Show($"Catégorie sélectionnée: {displayName}\n\n(Navigation à implémenter avec DbContext)",
                          "Catégorie",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        #endregion

            private void OnSearchRequested(string query)
            {
                // TODO: Logique de recherche
            }

            private void OnCategorySelected(string category)
            {
                // TODO: Logique de sélection de catégorie
            }
        /// <summary>
        /// Gère la sélection d'une catégorie depuis le CategoryGrid
        /// </summary>
        private void HandleCategorySelected(CategoryAllowed category)
        {
            OnCategorySelected(category);
        }

    }

}