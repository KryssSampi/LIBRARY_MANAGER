﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.ViewModels;
using LIBBRARY_MANAGER.ViewModel.BookViewModels;
using LIBBRARY_MANAGER.Views.BookViews;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.Views.MainView
{
    /// <summary>
    /// MainView - Vue réutilisable pour afficher une liste/grille de livres
    /// ÉPURÉE : Ne contient QUE la logique d'affichage UI
    /// </summary>
    public partial class Mainview : UserControl
    {
        #region Propriétés

        /// <summary>
        /// ViewModel (injecté ou créé automatiquement)
        /// </summary>
        public BookCatalogMainViewModel ViewModel { get; private set; }

        /// <summary>
        /// Collection des items UI actuellement affichés
        /// </summary>
        private ObservableCollection<UIElement> _displayedItems = new();

        #endregion

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut (crée son propre ViewModel)
        /// </summary>
        public Mainview() : this(new BookCatalogMainViewModel())
        {
        }

        /// <summary>
        /// Constructeur avec injection de ViewModel (recommandé)
        /// </summary>
        public Mainview(BookCatalogMainViewModel viewModel)
        {
            ViewModel = viewModel ?? throw new ArgumentNullException(nameof(viewModel));
            DataContext = ViewModel;

            InitializeComponent();

            // Abonnements aux événements du ViewModel
            SubscribeToViewModelEvents();

            Loaded += OnLoaded;
            Unloaded += OnUnloaded;
        }

        #endregion

        #region Cycle de vie

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Initialisation du ViewModel
                ViewModel?.Initialize();

                // Configuration des bindings complémentaires
                if (ViewModel != null)
                {
                    // Synchroniser SearchResultMessage avec ViewModel
                    SearchResultMessage_.DataContext = ViewModel;
                    ActiveFiltersPanel_.DataContext = ViewModel;
                    StatusBar_.DataContext = ViewModel;
                    NavigationBar_.DataContext = ViewModel;
                    ColumnHeaderPanel_.DataContext = ViewModel;
                }

                // Mise à jour initiale de l'affichage
                UpdateBooksDisplay();
            }
            catch (Exception ex)
            {
                ShowError("Erreur lors du chargement", ex);
            }
        }

        private void OnUnloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ViewModel?.Cleanup();
                UnsubscribeFromViewModelEvents();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Erreur lors du nettoyage: {ex.Message}");
            }
        }

        #endregion

        #region Abonnements

        private void SubscribeToViewModelEvents()
        {
            if (ViewModel == null) return;

            // Écoute les changements de la collection de livres
            ViewModel.DisplayedBooks.CollectionChanged += (s, e) => UpdateBooksDisplay();

            // Écoute les changements de mode de vue
            ViewModel.PropertyChanged += (s, e) =>
            {
                if (e.PropertyName == nameof(ViewModel.CurrentViewMode))
                {
                    UpdateBooksDisplay();
                }
            };
        }

        private void UnsubscribeFromViewModelEvents()
        {
            // Nettoyage si nécessaire
        }

        #endregion

        #region Mise à jour de l'affichage

        /// <summary>
        /// Rafraîchit l'affichage des livres selon le mode (List/Grid)
        /// </summary>
        private void UpdateBooksDisplay()
        {
            if (ViewModel == null) return;

            try
            {
                // Nettoyage du conteneur
                BooksGrid.Children.Clear();

                // Configuration du layout selon le mode
                ConfigureGridLayout();

                // Génération des items
                foreach (var book in ViewModel.DisplayedBooks)
                {
                    UIElement item = ViewModel.CurrentViewMode == ViewMode.List
                        ? BookViewModel.GetListItem(book)
                        : BookViewModel.GetGridItem(book);

                    BooksGrid.Children.Add(item);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Erreur lors de la mise à jour: {ex.Message}");
            }
        }

        /// <summary>
        /// Configure le layout de la grille selon le mode
        /// </summary>
        private void ConfigureGridLayout()
        {
            if (ViewModel.CurrentViewMode == ViewMode.List)
            {
                // Mode Liste : 1 colonne
                BooksGrid.Columns = 1;
            }
            else
            {
                // Mode Grille : calcul adaptatif selon la largeur
                BooksGrid.Columns = CalculateGridColumns();
            }
        }

        /// <summary>
        /// Calcule le nombre de colonnes selon la largeur disponible
        /// </summary>
        private int CalculateGridColumns()
        {
            var availableWidth = ActualWidth > 0 ? ActualWidth : 1200;
            const int minItemWidth = 250;

            int columns = (int)(availableWidth / minItemWidth);
            return Math.Max(1, Math.Min(columns, 6)); // Entre 1 et 6 colonnes
        }

        #endregion

        #region Méthodes publiques (API pour utilisation externe)

        /// <summary>
        /// Charge une catégorie spécifique
        /// </summary>
        public void LoadCategory(Model.Book.CategoryAllowed category)
        {
            try
            {
                ViewModel?.LoadBooksForCategory(category);
            }
            catch (Exception ex)
            {
                ShowError($"Erreur lors du chargement de la catégorie", ex);
            }
        }

        /// <summary>
        /// Effectue une recherche
        /// </summary>
        public void PerformSearch(string searchText)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(searchText))
                {
                    ViewModel?.ClearSearchCommand.Execute(null);
                }
                else
                {
                    ViewModel?.Search(searchText);
                }
            }
            catch (Exception ex)
            {
                ShowError("Erreur lors de la recherche", ex);
            }
        }

        /// <summary>
        /// Rafraîchit l'affichage
        /// </summary>
        public void Refresh()
        {
            try
            {
                ViewModel?.ReloadCommand.Execute(null);
            }
            catch (Exception ex)
            {
                ShowError("Erreur lors du rafraîchissement", ex);
            }
        }

        /// <summary>
        /// Change le mode d'affichage
        /// </summary>
        public void ToggleViewMode()
        {
            try
            {
                ViewModel?.ToggleViewModeCommand.Execute(null);
            }
            catch (Exception ex)
            {
                ShowError("Erreur lors du changement de vue", ex);
            }
        }

        #endregion

        #region Gestion d'erreurs

        private void ShowError(string message, Exception ex)
        {
            var errorMessage = $"{message}\n\n{ex.Message}";
            MessageBox.Show(
                errorMessage,
                "Erreur",
                MessageBoxButton.OK,
                MessageBoxImage.Error
            );

            System.Diagnostics.Debug.WriteLine($"[ERROR] {errorMessage}\n{ex.StackTrace}");
        }

        #endregion

        #region Gestion du redimensionnement

        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);

            // Recalculer les colonnes en mode grille
            if (ViewModel?.CurrentViewMode == ViewMode.Grid)
            {
                ConfigureGridLayout();
            }
        }

        #endregion
    }
}