﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using GalaSoft.MvvmLight.CommandWpf;
using LIBBRARY_MANAGER.Model;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Config;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Core.Services;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Core.Services.LIBBRARY_MANAGER.Services.BookCatalog;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Core.TestCase;
using LIBBRARY_MANAGER.UI.Modules.BookCatalog.Items;
using MahApps.Metro.IconPacks;
using static LIBBRARY_MANAGER.Model.Book;

namespace LIBBRARY_MANAGER.UI.Modules.BookCatalog.ViewModels
{
    public enum ViewMode
    {
        List,
        Grid
    }

    /// <summary>
    /// ViewModel principal du catalogue de livres
    /// Gestion centralisée de l'état et de la logique métier
    /// </summary>
    public class BookCatalogMainViewModel : INotifyPropertyChanged
    {
        #region Services

        private readonly BookSearchService _searchService;
        private readonly BookSortService _sortService;
        private readonly BookFilterService _filterService;
        private readonly CategoryCountService _categoryCountService;

        #endregion

        #region Collections de données

        private ObservableCollection<Book> _allBooks;
        public ObservableCollection<Book> AllBooks
        {
            get => _allBooks;
            set { _allBooks = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Book> _displayedBooks;
        public ObservableCollection<Book> DisplayedBooks
        {
            get => _displayedBooks;
            set { _displayedBooks = value; OnPropertyChanged(); UpdateTotalCount(); }
        }

        private ObservableCollection<FilterLabelViewModel> _activeFilters;
        public ObservableCollection<FilterLabelViewModel> ActiveFilters
        {
            get => _activeFilters;
            set { _activeFilters = value; OnPropertyChanged(); }
        }

        #endregion

        #region État de la vue

        private ViewMode _currentViewMode = ViewMode.List;
        public ViewMode CurrentViewMode
        {
            get => _currentViewMode;
            set
            {
                _currentViewMode = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsListMode));
                OnPropertyChanged(nameof(IsGridView));
                OnPropertyChanged(nameof(ViewModeText));
                UpdateViewModeIcon();
            }
        }

        public bool IsListMode => CurrentViewMode == ViewMode.List;
        public bool IsGridView => CurrentViewMode == ViewMode.Grid;
        public bool IsListView => CurrentViewMode == ViewMode.List; // Alias pour ColumnHeadersPanel
        public string ViewModeText => CurrentViewMode == ViewMode.List ? "Liste" : "Grille";

        private CategoryAllowed? _selectedCategory;
        public CategoryAllowed? SelectedCategory
        {
            get => _selectedCategory;
            set { _selectedCategory = value; OnPropertyChanged(); }
        }

        private string _searchQuery = string.Empty;
        public string SearchQuery
        {
            get => _searchQuery;
            set
            {
                _searchQuery = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(HasSearchQuery));
                OnPropertyChanged(nameof(SearchText)); // Alias pour binding XAML
            }
        }

        // Alias pour binding Mainview.xaml (NavigationBar SearchText)
        public string SearchText
        {
            get => SearchQuery;
            set => SearchQuery = value;
        }

        public bool HasSearchQuery => !string.IsNullOrWhiteSpace(SearchQuery);

        private int _totalBooksCount;
        public int TotalBooksCount
        {
            get => _totalBooksCount;
            set
            {
                _totalBooksCount = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(TotalResults)); // Alias pour StatusBar
            }
        }

        // Alias pour StatusBar.xaml binding
        public int TotalResults => TotalBooksCount;

        private string _currentSortColumn = "Titre";
        public string CurrentSortColumn
        {
            get => _currentSortColumn;
            set { _currentSortColumn = value; OnPropertyChanged(); }
        }

        private bool _currentSortAscending = true;
        public bool CurrentSortAscending
        {
            get => _currentSortAscending;
            set { _currentSortAscending = value; OnPropertyChanged(); }
        }

        #endregion

        #region Commandes

        public ICommand SearchCommand { get; }
        public ICommand ClearSearchCommand { get; }
        public ICommand ToggleViewModeCommand { get; }
        public ICommand ReloadCommand { get; }
        public ICommand BackCommand { get; set; } // Défini par BookCatalog.xaml.cs
        public ICommand SortCommand { get; }
        public ICommand RemoveFilterCommand { get; }

        // Alias pour Mainview.xaml binding
        public ICommand BackToCategoriesCommand
        {
            get => BackCommand;
            set => BackCommand = value;
        }

        #endregion

        #region Propriétés pour NavigationBar

        private PackIconMaterialKind _viewModeIcon = PackIconMaterialKind.ViewGridOutline;
        public PackIconMaterialKind ViewModeIcon
        {
            get => _viewModeIcon;
            set { _viewModeIcon = value; OnPropertyChanged(); }
        }

        #endregion

        #region Constructeur

        public BookCatalogMainViewModel()
        {
            // Initialisation des services
            _searchService = new BookSearchService();
            _sortService = new BookSortService();
            _filterService = new BookFilterService();
            _categoryCountService = new CategoryCountService();

            // Initialisation des collections
            _allBooks = new ObservableCollection<Book>();
            _displayedBooks = new ObservableCollection<Book>();
            _activeFilters = new ObservableCollection<FilterLabelViewModel>();

            // Abonnement aux changements de filtres
            _activeFilters.CollectionChanged += (s, e) => ApplyFiltersAndSort();

            // Initialisation des commandes
            SearchCommand = new RelayCommand(ExecuteSearch, CanExecuteSearch);
            ClearSearchCommand = new RelayCommand(ExecuteClearSearch);
            ToggleViewModeCommand = new RelayCommand(ExecuteToggleViewMode);
            ReloadCommand = new RelayCommand(ExecuteReload);
            SortCommand = new RelayCommand<string>(ExecuteSort);
            RemoveFilterCommand = new RelayCommand<string>(ExecuteRemoveFilter);

            // Chargement initial des données de test
            LoadInitialData();
        }

        #endregion

        #region Initialisation

        /// <summary>
        /// Charge les données initiales (test ou BDD)
        /// </summary>
        public void LoadInitialData()
        {
            // Charger les livres de test
            var sampleBooks = BookCatalogSample.GetSampleBooks();
            AllBooks = new ObservableCollection<Book>(sampleBooks);

            // Afficher tous les livres par défaut
            RefreshDisplayedBooks();
        }

        /// <summary>
        /// Initialise le ViewModel (appelé par la vue)
        /// </summary>
        public void Initialize()
        {
            if (AllBooks.Count == 0)
                LoadInitialData();
        }

        #endregion

        #region Méthodes principales

        /// <summary>
        /// Charge les livres d'une catégorie spécifique
        /// </summary>
        public void LoadBooksForCategory(CategoryAllowed category)
        {
            SelectedCategory = category;

            // Ajouter un filtre de catégorie
            var categoryName = CategoryConfiguration.GetConfig(category)?.DisplayName ?? category.ToString();

            var existingFilter = ActiveFilters.FirstOrDefault(f =>
                f.Type?.Equals("Catégorie", StringComparison.OrdinalIgnoreCase) ?? false
            );

            if (existingFilter != null)
            {
                existingFilter.Value = categoryName;
            }
            else
            {
                ActiveFilters.Add(new FilterLabelViewModel
                {
                    Id = $"cat_{category}",
                    Type = "Catégorie",
                    Value = categoryName
                });
            }

            ApplyFiltersAndSort();
        }

        /// <summary>
        /// Effectue une recherche
        /// </summary>
        public void Search(string query)
        {
            SearchQuery = query;
            ExecuteSearch();
        }

        /// <summary>
        /// Applique tous les filtres et tris
        /// </summary>
        private void ApplyFiltersAndSort()
        {
            var result = AllBooks.AsEnumerable();

            // 1. Recherche
            if (HasSearchQuery)
            {
                result = _searchService.Search(result, SearchQuery);
            }

            // 2. Filtres
            if (ActiveFilters.Any())
            {
                result = _filterService.ApplyFilters(result, ActiveFilters);
            }

            // 3. Tri
            result = _sortService.SortByColumnName(result, CurrentSortColumn, CurrentSortAscending);

            // Mise à jour de l'affichage
            RefreshDisplayedBooks(result);
        }

        /// <summary>
        /// Rafraîchit la liste affichée
        /// </summary>
        private void RefreshDisplayedBooks(IEnumerable<Book>? books = null)
        {
            var booksToDisplay = books ?? AllBooks;

            DisplayedBooks.Clear();
            foreach (var book in booksToDisplay)
            {
                DisplayedBooks.Add(book);
            }

            TotalBooksCount = DisplayedBooks.Count;
        }

        /// <summary>
        /// Obtient les compteurs de catégories
        /// </summary>
        public Dictionary<CategoryAllowed, int> GetCategoryCounts()
        {
            return _categoryCountService.GetCategoryCounts(AllBooks);
        }

        #endregion

        #region Commandes - Implémentations

        private bool CanExecuteSearch() => !string.IsNullOrWhiteSpace(SearchQuery);

        private void ExecuteSearch()
        {
            ApplyFiltersAndSort();
        }

        private void ExecuteClearSearch()
        {
            SearchQuery = string.Empty;
            ApplyFiltersAndSort();
        }

        private void ExecuteToggleViewMode()
        {
            CurrentViewMode = CurrentViewMode == ViewMode.List
                ? ViewMode.Grid
                : ViewMode.List;
        }

        private void UpdateViewModeIcon()
        {
            ViewModeIcon = CurrentViewMode == ViewMode.List
                ? PackIconMaterialKind.ViewGridOutline
                : PackIconMaterialKind.ViewList;
        }

        private void ExecuteReload()
        {
            LoadInitialData();
            ClearFilters();
            SearchQuery = string.Empty;
        }

        private void ExecuteSort(string? columnName)
        {
            if (string.IsNullOrEmpty(columnName))
                return;

            // Toggle direction si même colonne
            if (CurrentSortColumn.Equals(columnName, StringComparison.OrdinalIgnoreCase))
            {
                CurrentSortAscending = !CurrentSortAscending;
            }
            else
            {
                CurrentSortColumn = columnName;
                CurrentSortAscending = true;
            }

            ApplyFiltersAndSort();
        }

        private void ExecuteRemoveFilter(string? filterId)
        {
            if (string.IsNullOrEmpty(filterId))
                return;

            var filterToRemove = ActiveFilters.FirstOrDefault(f => f.Id == filterId);
            if (filterToRemove != null)
            {
                ActiveFilters.Remove(filterToRemove);

                // Si c'était un filtre de catégorie, réinitialiser
                if (filterToRemove.Type?.Equals("Catégorie", StringComparison.OrdinalIgnoreCase) ?? false)
                {
                    SelectedCategory = null;
                }
            }
        }

        #endregion

        #region Méthodes utilitaires publiques

        /// <summary>
        /// Ajoute un filtre manuellement
        /// </summary>
        public void AddFilter(string type, string value)
        {
            var filterId = $"{type}_{Guid.NewGuid():N}";
            ActiveFilters.Add(new FilterLabelViewModel
            {
                Id = filterId,
                Type = type,
                Value = value
            });
        }

        /// <summary>
        /// Efface tous les filtres
        /// </summary>
        public void ClearFilters()
        {
            ActiveFilters.Clear();
            SelectedCategory = null;
        }

        /// <summary>
        /// Nettoyage (appelé lors du unload)
        /// </summary>
        public void Cleanup()
        {
            // Libération des ressources si nécessaire
        }

        private void UpdateTotalCount()
        {
            TotalBooksCount = DisplayedBooks?.Count ?? 0;
        }

        #endregion

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}